const Label = ({ title, className }) => {
    return (
        <label className={className}>{title}</label>
    )
}
export default Label;